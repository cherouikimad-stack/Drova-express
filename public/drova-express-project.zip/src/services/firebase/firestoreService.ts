/**
 * Central Cloud Firestore Service for DROVA Express
 * Real-time synchronization across all commercial and management PCs
 */
import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  Timestamp,
  serverTimestamp,
  writeBatch
} from 'firebase/firestore';
import { db } from './config';
import {
  Prospect,
  CRMCall,
  CRMFollowUp,
  ExpediteurProfile,
  CommercialFeedback,
  NotificationItem,
  AuditLog,
  UserAccount
} from '../../types';
import type { AdminSettings } from '../storage';

export const firestoreService = {
  // ================= PROSPECTS =================
  subscribeProspects(onUpdate: (prospects: Prospect[]) => void, onError?: (err: any) => void) {
    const colRef = collection(db, 'prospects');
    return onSnapshot(
      colRef,
      snapshot => {
        const list: Prospect[] = [];
        snapshot.forEach(d => {
          list.push({ id: d.id, ...(d.data() as any) });
        });
        onUpdate(list);
      },
      error => {
        console.warn('Prospects Firestore snapshot warning:', error);
        if (onError) onError(error);
      }
    );
  },

  async saveProspect(prospect: Prospect): Promise<void> {
    const docRef = doc(db, 'prospects', prospect.id);
    await setDoc(docRef, { ...prospect, updatedAt: new Date().toISOString() }, { merge: true });
  },

  async updateProspect(id: string, updates: Partial<Prospect>): Promise<void> {
    const docRef = doc(db, 'prospects', id);
    await updateDoc(docRef, { ...updates, updatedAt: new Date().toISOString() });
  },

  async deleteProspect(id: string): Promise<void> {
    await deleteDoc(doc(db, 'prospects', id));
  },

  async saveProspectsBatch(prospects: Prospect[]): Promise<void> {
    if (!prospects || prospects.length === 0) return;
    const chunkSize = 400; // Under Firestore 500 limit
    for (let i = 0; i < prospects.length; i += chunkSize) {
      const chunk = prospects.slice(i, i + chunkSize);
      const batch = writeBatch(db);
      const now = new Date().toISOString();
      for (const p of chunk) {
        const ref = doc(db, 'prospects', p.id);
        batch.set(ref, { ...p, updatedAt: now }, { merge: true });
      }
      await batch.commit();
    }
  },

  async updateProspectsBatch(updates: { id: string; data: Partial<Prospect> }[]): Promise<void> {
    if (!updates || updates.length === 0) return;
    const chunkSize = 400;
    for (let i = 0; i < updates.length; i += chunkSize) {
      const chunk = updates.slice(i, i + chunkSize);
      const batch = writeBatch(db);
      const now = new Date().toISOString();
      for (const item of chunk) {
        const ref = doc(db, 'prospects', item.id);
        batch.update(ref, { ...item.data, updatedAt: now });
      }
      await batch.commit();
    }
  },

  async deleteProspectsBatch(ids: string[]): Promise<void> {
    if (!ids || ids.length === 0) return;
    const chunkSize = 400;
    for (let i = 0; i < ids.length; i += chunkSize) {
      const chunk = ids.slice(i, i + chunkSize);
      const batch = writeBatch(db);
      for (const id of chunk) {
        batch.delete(doc(db, 'prospects', id));
      }
      await batch.commit();
    }
  },

  // ================= CALLS =================
  subscribeCalls(onUpdate: (calls: CRMCall[]) => void, onError?: (err: any) => void) {
    const colRef = collection(db, 'calls');
    return onSnapshot(
      colRef,
      snapshot => {
        const list: CRMCall[] = [];
        snapshot.forEach(d => {
          list.push({ id: d.id, ...(d.data() as any) });
        });
        onUpdate(list);
      },
      error => {
        console.warn('Calls Firestore snapshot warning:', error);
        if (onError) onError(error);
      }
    );
  },

  async recordCall(call: CRMCall): Promise<void> {
    const docRef = doc(db, 'calls', call.id);
    await setDoc(docRef, {
      ...call,
      created_at: call.date || new Date().toISOString()
    });
  },

  // ================= FOLLOW-UPS =================
  subscribeFollowUps(onUpdate: (followUps: CRMFollowUp[]) => void, onError?: (err: any) => void) {
    const colRef = collection(db, 'followUps');
    return onSnapshot(
      colRef,
      snapshot => {
        const list: CRMFollowUp[] = [];
        snapshot.forEach(d => {
          list.push({ id: d.id, ...(d.data() as any) });
        });
        onUpdate(list);
      },
      error => {
        console.warn('FollowUps Firestore snapshot warning:', error);
        if (onError) onError(error);
      }
    );
  },

  async saveFollowUp(followUp: CRMFollowUp): Promise<void> {
    const docRef = doc(db, 'followUps', followUp.id);
    await setDoc(docRef, followUp, { merge: true });
  },

  async updateFollowUp(id: string, updates: Partial<CRMFollowUp>): Promise<void> {
    const docRef = doc(db, 'followUps', id);
    await updateDoc(docRef, updates);
  },

  // ================= EXPEDITEURS =================
  subscribeExpediteurs(onUpdate: (expediteurs: ExpediteurProfile[]) => void, onError?: (err: any) => void) {
    const colRef = collection(db, 'expediteurs');
    return onSnapshot(
      colRef,
      snapshot => {
        const list: ExpediteurProfile[] = [];
        snapshot.forEach(d => {
          list.push({ id: d.id, ...(d.data() as any) });
        });
        onUpdate(list);
      },
      error => {
        console.warn('Expediteurs Firestore snapshot warning:', error);
        if (onError) onError(error);
      }
    );
  },

  async saveExpediteur(expediteur: ExpediteurProfile): Promise<void> {
    const docRef = doc(db, 'expediteurs', expediteur.id);
    await setDoc(docRef, expediteur, { merge: true });
  },

  async updateExpediteur(id: string, updates: Partial<ExpediteurProfile>): Promise<void> {
    const docRef = doc(db, 'expediteurs', id);
    await updateDoc(docRef, updates);
  },

  // ================= COMMERCIAL FEEDBACKS =================
  subscribeFeedbacks(onUpdate: (feedbacks: CommercialFeedback[]) => void, onError?: (err: any) => void) {
    const colRef = collection(db, 'commercialFeedbacks');
    return onSnapshot(
      colRef,
      snapshot => {
        const list: CommercialFeedback[] = [];
        snapshot.forEach(d => {
          list.push({ id: d.id, ...(d.data() as any) });
        });
        onUpdate(list);
      },
      error => {
        console.warn('Feedbacks Firestore snapshot warning:', error);
        if (onError) onError(error);
      }
    );
  },

  async saveFeedback(feedback: CommercialFeedback): Promise<void> {
    const docRef = doc(db, 'commercialFeedbacks', feedback.id);
    await setDoc(docRef, feedback, { merge: true });
  },

  // ================= NOTIFICATIONS =================
  subscribeNotifications(onUpdate: (notifications: NotificationItem[]) => void, onError?: (err: any) => void) {
    const colRef = collection(db, 'notifications');
    return onSnapshot(
      colRef,
      snapshot => {
        const list: NotificationItem[] = [];
        snapshot.forEach(d => {
          list.push({ id: d.id, ...(d.data() as any) });
        });
        onUpdate(list);
      },
      error => {
        console.warn('Notifications Firestore snapshot warning:', error);
        if (onError) onError(error);
      }
    );
  },

  async saveNotification(notification: NotificationItem): Promise<void> {
    const docRef = doc(db, 'notifications', notification.id);
    await setDoc(docRef, notification, { merge: true });
  },

  async updateNotification(id: string, updates: Partial<NotificationItem>): Promise<void> {
    const docRef = doc(db, 'notifications', id);
    await updateDoc(docRef, updates);
  },

  // ================= AUDIT LOGS =================
  async recordAuditLog(entry: Omit<AuditLog, 'id'>): Promise<void> {
    const id = `audit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const docRef = doc(db, 'auditLogs', id);
    await setDoc(docRef, { ...entry, id });
  },

  async getAuditLogs(): Promise<AuditLog[]> {
    try {
      const q = query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'), limit(150));
      const snap = await getDocs(q);
      const list: AuditLog[] = [];
      snap.forEach(d => list.push(d.data() as AuditLog));
      return list;
    } catch {
      return [];
    }
  },

  // ================= USERS =================
  subscribeUsers(onUpdate: (users: UserAccount[]) => void, onError?: (err: any) => void) {
    const colRef = collection(db, 'users');
    return onSnapshot(
      colRef,
      snapshot => {
        const list: UserAccount[] = [];
        snapshot.forEach(d => {
          const data = d.data();
          list.push({
            id: d.id,
            full_name: data.fullName || data.full_name || data.username || '',
            username: data.username || '',
            password_hash: data.password_hash || '',
            salt: data.salt || '',
            role: (data.role || 'COMMERCIAL').toLowerCase(),
            status: data.status || 'active',
            phone: data.phone || '',
            email: data.email || '',
            created_at: data.createdAt || data.created_at || new Date().toISOString(),
            last_login: data.lastLogin || data.last_login
          });
        });
        onUpdate(list);
      },
      error => {
        console.warn('Users Firestore snapshot warning:', error);
        if (onError) onError(error);
      }
    );
  },

  async saveUser(user: UserAccount): Promise<void> {
    const docRef = doc(db, 'users', user.id);
    await setDoc(docRef, {
      id: user.id,
      username: user.username.toLowerCase(),
      fullName: user.full_name,
      role: user.role.toUpperCase(),
      status: user.status || 'active',
      phone: user.phone || '',
      email: user.email || `${user.username}@drova-crm.internal`,
      password_hash: user.password_hash || '',
      salt: user.salt || '',
      createdAt: user.created_at || new Date().toISOString(),
      lastLogin: user.last_login || null
    }, { merge: true });
  },

  async updateUser(id: string, updates: any): Promise<void> {
    const docRef = doc(db, 'users', id);
    await updateDoc(docRef, updates);
  },

  async deleteUser(id: string): Promise<void> {
    await deleteDoc(doc(db, 'users', id));
  }
};
