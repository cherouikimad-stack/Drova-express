# DROVA EXPRESS — Merchant Intelligence & Commercial CRM
### منصة استخبارات التجار الوطنية وإدارة الشاحنين لشركة DROVA Express الجزائر

منصة مؤسساتية متكاملة وسحابية مصممة خصيصاً لشركة **DROVA Express الجزائر**، تتيح استكشاف آلاف التجار وأصحاب المتاجر الإلكترونية عبر 58 ولاية، توثيق وتطبيع أرقام الهواتف، توزيع المهام على المندوبين التجاريين، وإدارة دورة حياة الشاحنين (Expéditeurs CRM) في بيئة مركزية مشتركة بين جميع حواسيب الشركة في وقت واحد.

---

## 🏗 البنية التقنية السحابية (Full-Stack Cloud Architecture)
- **الواجهة الأمامية (Frontend):** React 19 + TypeScript + Tailwind CSS v4 + Motion.
- **إدارة الحزم والبناء:** Vite 8 فائق السرعة.
- **قاعدة البيانات المركزية:** Google Cloud Firestore (تزامن لحظي Real-time عبر WebSockets لجميع الأجهزة).
- **المصادقة وإدارة الهوية:** Firebase Authentication بنظام تحويل أسماء المستخدمين (Username-to-Internal-Email).
- **الأمان والتحكم:** Attribute-Based Access Control (ABAC) مدعوم بـ `firestore.rules` و Custom Claims.
- **المنطق الخلفي والأسرار:** Firebase Cloud Functions (Node.js 20) لتنفيذ مهام الذكاء الاصطناعي (Gemini 2.5 Flash) وإدارة المستخدمين دون كشف أي أسرار للمتصفح.
- **الاستضافة السحابية:** Firebase Hosting مع دعم شهادات SSL وتوجيه النطاق المخصص `crm.drova.dz`.

---

## 🚀 التشغيل والتطوير المحلي (Local Development)

### 1. تثبيت الحزم
```bash
npm install
```

### 2. تشغيل خادم التطوير
```bash
npm run dev
```
التطبيق سيعمل على المنفذ `http://localhost:3000`.

### 3. تشغيل محاكي Firebase المحلي (Firebase Emulator Suite)
للاختبار المحلي بالكامل دون التأثير على قاعدة بيانات الإنتاج:
```bash
firebase emulators:start
```
يوفر المحاكي:
- **Auth Emulator:** `http://localhost:9099`
- **Firestore Emulator:** `http://localhost:8080`
- **Emulator UI:** `http://localhost:4000`

---

## 📦 بناء الإنتاج (Production Build)
```bash
# فحص الكود والتأكد من خلوه من الأخطاء
npm run lint

# بناء الحزمة النهائية
npm run build
```
تُحفظ ملفات الإنتاج الجاهزة في مجلد `dist/`.

---

## 🌐 النشر على Firebase (Firebase Deployment)

### نشر كامل المنصة بضغطة زر
```bash
firebase deploy
```

### نشر أجزاء محددة
```bash
# نشر قواعد بيانات وأمان Firestore
firebase deploy --only firestore:rules

# نشر فهارس البحث المركبة
firebase deploy --only firestore:indexes

# نشر دوال الخادم Cloud Functions
firebase deploy --only functions

# نشر الواجهة الأمامية Hosting
firebase deploy --only hosting
```

---

## 🔑 تسجيل الدخول الأول وإنشاء الحسابات (Admin Setup)

### 1. حساب المشرف الرئيسي المعتمد (Super Admin)
- **اسم المستخدم:** `cherouik`
- **كلمة المرور:** `admin123@`

### 2. حساب المندوب التجاري التجريبي (Commercial Rep)
- **اسم المستخدم:** `mouradkarmoula`
- **كلمة المرور:** `mourad123@`

> **تنبيه أمان:** بمجرد الدخول إلى النظام، يرجى التوجه إلى **الإعدادات ← المستخدمون** وتغيير كلمات المرور الأولية.

---

## 🌍 ربط النطاق المخصص (Connecting crm.drova.dz)
1. في **Firebase Console** ← انتقل إلى **Hosting**.
2. انقر على **"Add custom domain"**.
3. اكتب النطاق: `crm.drova.dz`.
4. انسخ سجلات الـ DNS (سجلات A و TXT) وضعها في لوحة تحكم مزود النطاق الخاص بشركة DROVA.
5. ستقوم Google بإصدار شهادة SSL مشفرة وتفعيل رابط HTTPS خلال بضع ساعات تلقائياً.

---

## 💾 النسخ الاحتياطي واستعادة الكوارث (Backup & Recovery)
- **التحميل اليدوي:** من واجهة **الإعدادات ← النسخ الاحتياطي**، انقر على **"تنزيل لقطة قاعدة البيانات (Snapshot JSON)"** لحفظ نسخة محلية مشفرة بجميع التجار والمكالمات والشاحنين.
- **الاستعادة الفورية:** في حال حدوث أي طارئ، يمكنك رفع ملف النسخة الاحتياطية واستعادة قاعدة البيانات بالكامل بضغطة زر واحدة.

---

## 🛠 استكشاف الأخطاء الشائعة (Troubleshooting)

| المشكلة | السبب المحتمل | الحل |
| :--- | :--- | :--- |
| **User not authorized** | الحساب معطل أو الدور غير مطابق | تأكد من تفعيل الحساب من قِبل الـ Super Admin في لوحة المستخدمين. |
| **Firestore offline warning** | انقطاع اتصال الإنترنت أو عدم توثيق القواعد | النظام يعمل تلقائياً بذاكرة الكاش المحلية ويعيد المزامنة فور عودة الاتصال. |
| **Missing index error** | استعلام مركب جديد يحتاج فهرس | افتح الرابط المباشر الموجود في Console لإنشاء الفهرس بضغطة زر أو نفذ `firebase deploy --only firestore:indexes`. |

---

**Developed by Cherouik Imad** · DROVA Express Algérie © 2026 · All Rights Reserved
