/**
 * ==============================================================================
 * DROVA Express Algeria — Discovery API Credentials & Keys Configuration
 * ==============================================================================
 * يمكنك وضع وتعديل مفاتيح الـ API الخاصة بك هنا مباشرة في هذا الملف:
 * 
 * 1. GOOGLE_PLACES_API_KEY: مفتاح Google Places API (New)
 * 2. META_ACCESS_TOKEN: رمز وصول Meta Ad Library / Graph API
 * 3. GOOGLE_PLACES_CUSTOM_REFERER: عنوان المرجع المسموح (اختياري لحل قيود Referer)
 * ==============================================================================
 */

export const API_CREDENTIALS = {
  // مفتاح Google Places API (New) — ضَع مفتاحك هنا
  GOOGLE_PLACES_API_KEY: process.env.GOOGLE_PLACES_API_KEY || 'AIzaSyDfzBl7A2wGuCV7qdyYunRFKF4Sxud7bTo',

  // رمز وصول Meta Ad Library API — ضَع الرمز هنا (EAA...)
  META_ACCESS_TOKEN: process.env.META_ACCESS_TOKEN || '',

  // عنوان HTTP Referer المسموح (اختياري: مثال https://drova-express.netlify.app/)
  GOOGLE_PLACES_CUSTOM_REFERER: process.env.GOOGLE_PLACES_CUSTOM_REFERER || '',
};
